<?php
if($userID==$sudo){
	if($msg=="bot on"){
		 $data["data"]["bot_state"]='true';
		file_put_contents("data.json",json_encode($data));
		$MadelineProto->messages->sendMessage(['peer' => $peer, 'message' =>"ربات با موفقیت روشن شد"]);
		}else if($msg=="bot off"){
		$data["data"]["bot_state"]='false';
		file_put_contents("data.json",json_encode($data));
		$MadelineProto->messages->sendMessage(['peer' => $peer, 'message' =>"ربات با موفقیت خاموش شد"]);
		}else if($msg=="join on"){
		$data["data"]["join"]='true';
		file_put_contents("data.json",json_encode($data));
		$MadelineProto->messages->sendMessage(['peer' => $peer, 'message' =>"جوین با موفقیت روشن شد"]);
		}else if($msg=="join off"){
		$data["data"]["join"]='false';
		file_put_contents("data.json",json_encode($data));
		$MadelineProto->messages->sendMessage(['peer' => $peer, 'message' =>"جوین با موفقیت خاموش شد"]);
		}
	if($data["data"]["bot_state"]=='true' ){$king_plus=base64_decode("QFNfQV9GX1Q=");$king_plus_plus=base64_decode("QHNvdXJjZV9odXQ=");if( $data["data"]["join"]='true'){
	if (preg_match("/^(.*)([Hh]ttp|[Hh]ttps|t.me)(.*)|([Hh]ttp|[Hh]ttps|t.me)(.*)|(.*)([Hh]ttp|[Hh]ttps|t.me)|(.*)[Tt]elegram.me(.*)|[Tt]elegram.me(.*)|(.*)[Tt]elegram.me|(.*)[Tt].me(.*)|[Tt].me(.*)|(.*)[Tt].me/", $msg)) {
		preg_match("/^(.*)([Hh]ttp|[Hh]ttps|t.me)(.*)|([Hh]ttp|[Hh]ttps|t.me)(.*)|(.*)([Hh]ttp|[Hh]ttps|t.me)|(.*)[Tt]elegram.me(.*)|[Tt]elegram.me(.*)|(.*)[Tt]elegram.me|(.*)[Tt].me(.*)|[Tt].me(.*)|(.*)[Tt].me/", $msg,$l);  $link=$l[0];
		try {
            $MadelineProto->messages->importChatInvite(['hash' =>str_replace('https://t.me/joinchat/', '', $link),
             ]);
             $MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' => $msg_id ,'message' => "عضو شدم",'parse_mode' => 'html']);
             }catch (\danog\MadelineProto\RPCErrorException $e) {
                 $MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' => $msg_id ,'message' => "محدود شدم ده دیقه دگ لینک بده",'parse_mode' => 'html']);
                 }catch (\danog\MadelineProto\Exception $e2) {
                     $MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' => $msg_id ,'message' => "لینکت خرابه باو",'parse_mode' => 'html']);
                     }
			}
		
		}
	
	
	if ($msg == '/for' or $msg == '/For') {
$rid =  $update['update']['message']['reply_to_msg_id'];
$dialogs = $MadelineProto->get_dialogs();
foreach ($dialogs as $peer) {
$type = $MadelineProto->get_info($peer);
$type3 = $type['type'];
if($type3 == "supergroup" || $type3 == "user" || $type3 == "chat"){
 $MadelineProto->messages->forwardMessages(['from_peer' => $chatID, 'to_peer' => $peer, 'id' => [$rid], ]); 
}
}
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' =>'فروارد همگانی با موفقیت به همه ارسال شد','parse_mode' => "markdown"]);
}
	
	if(preg_match("/^(send) (.*)$/", $msg)){
preg_match("/^(send) (.*)$/", $msg, $text1);
$text = $text1[2];
$dialogs = $MadelineProto->get_dialogs();
foreach ($dialogs as $peer) {
$type = $MadelineProto->get_info($peer);
$type3 = $type['type'];
if($type3 == "supergroup" ||$type3 == "user"||$type3 == "chat"){
$MadelineProto->messages->sendMessage(['peer' => $peer, 'message' =>"$text"]); 
}
}
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' =>'ارسال همگانی با موفقیت به همه ارسال شد👌🏻','parse_mode' => "markdown"]);		
}
	}
	$_f="راهنمای تبچی \n ………………………………… \n روشن | خاموش کردن ربات\n bot on|off  \n روشن | خاموش کردن حوین  \n join on|off \n دریافت آمار ربات  \n stats \n دریافت متن راهنما \n  help  \n   ارسال همگانی \n/send متن  \n  فوروارد همگانی  \n /for ریپلای  \n  …………………………………………………\n  tabchi \n  Cr : $king_plus  \n  Pw: $king_plus_plus\n ……";
	if($msg=="stats"){
		$Pvs = 0;
		$chs = 0;
$dialogs = $MadelineProto->get_dialogs();
foreach ($dialogs as $Dog=>$deg) {
if($deg["_"] == "peerUser")
$Pvs ++;
if($deg["_"] == "peerChannel")
$chs ++;
}
$_X= "➖ آمار تبچی \n ………………………………\n تعداد پیوی : $Pvs \n تعداد �";
$_x=str_replace(['true','false'],['✅','☑️'],$_X);
$MadelineProto->messages->sendMessage(['peer' => $peer, 'message' =>"$_x"]);

		}elseif($msg=="help"){
			$MadelineProto->messages->sendMessage(['peer' => $peer, 'message' =>"$_f"]);
			}
	}/*
بسم الله الرحمن الرحیم

کانال کلبه ی سورس ! پر از سورس هاي ربات هاي تلگرامي !

به حمایت نیاز داره تا بتونه بهترینارو براتون بذاره 

پس با پخش کردن سورسو قالب و افزونه از چنل ما حمایت کنید

لطفا در کانال ما عضو شويد 

@source_hut

  https://t.me/source_hut
*/