<?php
/*
بسم الله الرحمن الرحیم

کانال کلبه ی سورس ! پر از سورس هاي ربات هاي تلگرامي !

به حمایت نیاز داره تا بتونه بهترینارو براتون بذاره 

پس با پخش کردن سورسو قالب و افزونه از چنل ما حمایت کنید

لطفا در کانال ما عضو شويد 

@source_hut

  https://t.me/source_hut
*/
date_default_timezone_set('Asia/Tehran');
$sudo =774576167 ; /// ایدی عددی سودو
$listplugins = [
  "in",
  ];
 
$com=file_get_contents("com.txt");
$data = json_decode(file_get_contents("data.json"),true);
$bot_state = $data["data"]["bot_state"];
$join = $data["data"]["join"];
//----------------------------------
if (!file_exists('data.json')) {
 $data["data"]["bot_state"]='true';
 $data["data"]["join"]='true';
file_put_contents("data.json",json_encode($data));
}
//---------------------------------------
$cplug = count($listplugins) - 1;
for($n=0; $n<=$cplug; $n++) {
  $pluginlist = "plugins/".$listplugins[$n].".php";
  include($pluginlist);
}
